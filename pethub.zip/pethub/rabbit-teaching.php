<?php
include 'connection.php'; // Assuming the connection to the database
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=bookmark" />
  <link href="https://fonts.googleapis.com/css2?family=Georama:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Georama:ital,wght@0,100..900;1,100..900&family=Libre+Franklin:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Georama:ital,wght@0,100..900;1,100..900&family=Libre+Franklin:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <link rel="stylesheet" href="general.css">
  <link rel="stylesheet" href="navbar.css">
  <link rel="stylesheet" href="contents.css">
  <title>Pet Hub</title>
  <link rel="icon" type="image/x-icon" href="favicon.ico">

</head>
<body>
<div class="navbar">
  <div class="left-section">
    <div class="logo-icon">
      <img class="logo-image" src="/pethub/img/logo2.png">
    </div>
    <div class="infurrmation-hub">    
      <h1>INFURRMATION HUB</h1>
    </div>
  </div>
  <div class="middle-section">
    <!-- Main Dropdown for Exotic Pets -->
    <div class="dropdown">
      <button class="button-style" id="button-spacing"><p>Domestic Pets</p><div class="chevron-down"><i class="fa fa-chevron-down"></i></div></button>
      <div class="dropdown-content">
          <!-- Dogs Dropdown -->
          <div class="nested-dropdown">
              <a href="dogs.php#grooming">Dogs</a>
              <div class="nested-dropdown-content">
                  <a href="dogs.php#grooming">Grooming</a>
                  <a href="dogs-environment.php#environment">Proper Environment/Caging</a>
                  <a href="dogs-nutrition.php#nutrition">Nutrition</a>
                  <a href="dogs-teaching.php#teaching">Dos and Don’ts</a>
                 
              </div>
          </div>

          <!-- Cats Dropdown -->
          <div class="nested-dropdown">
              <a href="cats.php#grooming">Cats</a>
              <div class="nested-dropdown-content">
                  <a href="cats-grooming.php#grooming">Grooming</a>
                  <a href="cats-environment.php#environment">Proper Environment/Caging</a>
                  <a href="cats-nutrition.php#nutrition">Nutrition</a>
                  <a href="cats-teaching.php#teaching">Dos and Don’ts</a>
                 
              </div>
          </div>

          <!-- Birds Dropdown -->
          <div class="nested-dropdown">
              <a href="birds.php#grooming">Birds</a>
              <div class="nested-dropdown-content">
                  <a href="birds-grooming.php#grooming">Grooming</a>
                  <a href="birds-environment.php#environment">Proper Environment/Caging</a>
                  <a href="birds-nutrition.php#nutrition">Nutrition</a>
                  <a href="birds-teaching.php#teaching">Dos and Don’ts</a>
                  
              </div>
          </div>

          <!-- Fishes Dropdown -->
          <div class="nested-dropdown">
              <a href="fishes.php#grooming">Fishes</a>
              <div class="nested-dropdown-content">
                  <a href="fishes-grooming.php#grooming">Grooming</a>
                  <a href="fishes-environment.php#environment">Proper Environment/Caging</a>
                  <a href="fishes-nutrition.php#nutrition">Nutrition</a>
                  <a href="fishes-teaching.php#teaching">Dos and Don’ts</a>
                 
              </div>
          </div>

          <!-- Rabbit Dropdown -->
          <div class="nested-dropdown">
              <a href="rabbit.php#grooming">Rabbit</a>
              <div class="nested-dropdown-content">
                  <a href="rabbit-grooming.php#grooming">Grooming</a>
                  <a href="rabbit-environment.php#environment">Proper Environment/Caging</a>
                  <a href="rabbit-nutrition.php#nutrition">Nutrition</a>
                  <a href="rabbit-teaching.php#teaching">Dos and Don’ts</a>
                 
              </div>
          </div>

          <!-- Rodents Dropdown -->
          <div class="nested-dropdown">
              <a href="rodents.php#grooming">Rodents</a>
              <div class="nested-dropdown-content">
                  <a href="rodents-grooming.php#grooming">Grooming</a>
                  <a href="rodents-environment.php#environment">Proper Environment/Caging</a>
                  <a href="rodents-nutrition.php#nutrition">Nutrition</a>
                  <a href="rodents-teaching.php#teaching">Dos and Don’ts</a>
                 
              </div>
          </div>
      </div>
    </div>
    <!-- Main Dropdown for Exotic Pets -->
    <div class="dropdown">
      <button class="button-style"><p>Exotic Pets</p> <div class="chevron-down"><i class="fa fa-chevron-down"></i></div></button>
      <div class="dropdown-content">
          <!-- Ball Python Dropdown -->
          <div class="nested-dropdown">
              <a href="ballpython.php#grooming">Snake (Ball Python)</a>
              <div class="nested-dropdown-content">
                  <a href="ballpython-grooming.php#grooming">Grooming</a>
                  <a href="ballpython-environment.php#environment">Proper Environment/Caging</a>
                  <a href="ballpython-nutrition.php#nutrition">Nutrition</a>
                  <a href="ballpython-teaching.php#teaching">Dos and Don’ts</a>
                 
              </div>
          </div>

          <!-- Tarantulas Dropdown -->
          <div class="nested-dropdown">
              <a href="tarantulas.php#grooming">Tarantulas</a>
              <div class="nested-dropdown-content">
                  <a href="tarantulas-grooming.php#grooming">Grooming</a>
                  <a href="tarantulas-environment.php#environment">Proper Environment/Caging</a>
                  <a href="tarantulas-nutrition.php#nutrition">Nutrition</a>
                  <a href="tarantulas-teaching.php#teaching">Dos and Don’ts (Teaching)</a>
                 
              </div>
          </div>

          <!-- Domestic Pig Dropdown -->
          <div class="nested-dropdown">
              <a href="domesticpig.php#grooming">Domestic Pig</a>
              <div class="nested-dropdown-content">
                  <a href="domesticpig-grooming.php#grooming">Grooming</a>
                  <a href="domesticpig-environment.php#environment">Proper Environment/Caging</a>
                  <a href="domesticpig-nutrition.php#nutrition">Nutrition</a>
                  <a href="domesticpig-teaching.php#teaching">Dos and Don’ts (Teaching)</a>
                 
              </div>
          </div>

          <!-- Turtle Dropdown -->
          <div class="nested-dropdown">
              <a href="turtle.php#grooming">Turtle</a>
              <div class="nested-dropdown-content">
                  <a href="turtle-grooming.php#grooming">Grooming</a>
                  <a href="turtle-environment.php#environment">Proper Environment/Caging</a>
                  <a href="turtle-nutrition.php#nutrition">Nutrition</a>
                  <a href="turtle-teaching.php#teaching">Dos and Don’ts (Teaching)</a>
                 
              </div>
          </div>

          <!-- Hedgehogs Dropdown -->
          <div class="nested-dropdown">
              <a href="hedgehogs.php#grooming">Hedgehogs</a>
              <div class="nested-dropdown-content">
                  <a href="hedgehogs-grooming.php#grooming">Grooming</a>
                  <a href="hedgehogs-environment.php#environment">Proper Environment/Caging</a>
                  <a href="hedgehogs-nutrition.php#nutrition">Nutrition</a>
                  <a href="hedgehogs-teaching.php#teaching">Dos and Don’ts (Teaching)</a>
                  
              </div>
          </div>

          <!-- Axolotl Dropdown -->
          <div class="nested-dropdown">
              <a href="axolotl.php#grooming">Axolotl</a>
              <div class="nested-dropdown-content">
                  <a href="axolotl-grooming.php#grooming">Grooming</a>
                  <a href="axolotl-environment.php#environment">Proper Environment/Caging</a>
                  <a href="axolotl-nutrition.php#nutrition">Nutrition</a>
                  <a href="axolotl-teaching.php#teaching">Dos and Don’ts (Teaching)</a>
              </div>
          </div>
      </div>
    </div>
  </div>
  <div class="right-section">
    <div class="search-section">
      <input id="search-bar" class="search-bar" type="text" name="search" placeholder="Search" onclick="searchWords()">
      <img class="search-icon" src="/pethub/img/search.png" alt="search-icon" onclick="searchWords()">
    </div>
    
    <div class="profile-section">
      <form method="POST" action="index.php">
        <div class="profile-picture-section">
        <a href="index.php"><img class="profile-img" src="profile-picture-dog.png"></a>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- main -->
<div class="main">
  <div class="go-back-text">
    <a class="back-text" href="home.php"><div class="text-box">
      <div class="arrow-left">
        <i id="left-arrow" class="material-icons">
          keyboard_backspace
</i>
      </div>
        <div class="back-to-home-text">
          <p>Back to Home</p>
        </div>
    </div></a>
  </div>
 

  <div class="thumbnail-container">
    <img id="thumbnail" src="/pethub/img\RABBITS\RABBIT_Teaching.avif" alt="">
    <div class="corner"></div>
  </div>
  <div class="content">
    <div class="header-text">
      <h1 class="h1-text">Dos and Dont's of Rabbits</h1>
    </div>
    <div class="line-bar">
      <hr>
    </div>
    <div class="paragraph-section">
      <div class="paragraph" id="content">
      <h3>At a Glance: Rabbit Do’s</h3>
<p>Correct Diet- The correct foods and fresh water are essential for a rabbit’s health. So, always keep a steady supply of fresh hay on hand, and make sure that your rabbit’s water bowls and bottles are cleaned regularly.</p>
<p>Habitats- Rabbits need a place to call their own, even if they are free-roaming in your home. Giving your rabbits a hutch or habitat will help them feel safe and secure and offer them a little privacy occasionally.</p>
<p>Toys- Toys promote natural behaviors as well as encouraging physical movement and exercise. Also, toys can help prevent rabbits from chewing and shredding your furniture, and other valuables around your home.</p>
<p>Litter Box- Like all animals, rabbits need to go to the bathroom now and then, so it’s important to provide them with a litter box. And, keeping your rabbits’ litter box clean will help to keep your rabbits clean, too.</p>
<p>Proper Grooming- Even though rabbits are generally very clean animals, they still need a little help occasionally. So, be sure to brush them often to avoid mats and excess shedding and be sure to trim their nails on a regular basis.</p>
<h3>At a Glance: Rabbit Don’ts</h3>
<p>Overfeeding- Pellets and rabbit treats can be a good supplement to a rabbit’s diet but giving them too much can cause them to ignore their healthier foods, which can potentially lead to obesity and digestive issues.</p>
<p>Uncomfortable Contact- Rabbits are usually social animals, but they typically don’t like being touched on their chins, bellies or tails. Also, they don’t always like being picked up or held, so be prepared for them to respond unkindly if you force yourself upon them.</p>
<p>Unsafe Environment- Make sure that you keep all electrical cords and cables out of your rabbit’s reach. Cords and cables are very tempting for rabbits to chew on, and they can be very harmful to them if digested.</p>
<p>Not Spaying and Neutering- Regardless of how many rabbits you have, having them fixed can give them health and behavioral benefits. Spaying or neutering your bunnies can reduce their risk of testicular cancer, decrease aggressive behavior and prevent overbreeding.</p>
<p>Loneliness- Though rabbits tend to be very social, they usually do better with companions. If you are considering adopting one, you should consider adopting two to provide them with a happier existence.</p>
<h3>Rabbit Do’s</h3>
<ol>
  <li>
    <p>
      1. Give your Rabbit the Correct Diet
      Hay should constitute approximately 80% of a rabbit’s diet, so it’s very important that you always have a steady supply of fresh, quality hay on hand. In addition to hay, providing your bunnies with a helping of fresh, leafy greens once or twice a day gives them extra nutrients to help them thrive. And carefully measured helpings of commercial pellets can be an additional source of nutrients.
    </p>
  </li>
  <li>
    <p>
      2. Rabbits Need a Habitat
      Even if your rabbits are free roaming, they still require their own space and giving them a hutch or a habitat will provide them the right kind of living environment. Hutches and habitats give bunnies a feeling of safety and security. Plus, rabbits like a little privacy now and then.
    </p>
  </li>
  <li>
    <p>
      3. Toys are Important for Rabbits
      Toys are a very important part of your rabbit’s livelihood, as they encourage natural behaviors such as digging, chewing and chin rubbing, along with promoting physical movement and exercise. Also, toys can help prevent rabbits from chewing and shredding your furniture and other valuables around your home.
    </p>
  </li>
  <li>
    <p>
      4. Rabbits Require a Litter Box
      Although rabbits are generally very clean animals and spend a lot of time grooming themselves, they still require a litter box when nature calls. So, providing them with a litter box with quality litter or bedding is extremely important.
    </p>
  </li>
  <li>
    <p>
      5. Groom Your Rabbits Regularly
      As mentioned, rabbits like to keep themselves clean and spend a lot of time grooming themselves. However, this doesn’t mean that they don’t need a little help occasionally in that regard. Rabbits tend to shed a lot, and excess hair can lead to mats and rabbits can inhale and ingest excess hair, which can lead to respiratory and digestive issues.
    </p>
  </li>
</ol>
<h3>Rabbit Don’ts</h3>
<ol>
  <li>
    <p>
      1. Don’t Overfeed with Treats & Pellets
      As previously mentioned, fresh hay should be about 80% of a rabbit’s diet, and fresh, leafy greens provide them with additional nutrients. Hay and leafy greens are loaded with fiber and vitamins to help your bunnies thrive. However, treats and pellets can provide extra benefits if fed in the correct portions.
    </p>
  </li>
  <li>
    <p>
      2. Be Careful with Physical Contact
      Rabbits are absolutely some of the cutest, cuddliest animals that anyone has ever seen, but they also enjoy their personal space, so it’s important to respect their boundaries. Like most animals, bunnies enjoy some personal attention on occasion, and they usually enjoy being gently stroked on their heads and down their backs.
    </p>
  </li>
  <li>
    <p>
      3. Not Keeping Your Home Safe
      Regardless of their age, rabbits have a natural tendency to chew on things to help keep their teeth well-groomed, and this often includes things that aren’t food. It’s very common for bunnies to chew on wood and paper products, which are generally not harmful to them due to their evolved digestive systems.
    </p>
  </li>
  <li>
    <p>
      4. Not Spaying and Neutering Your Rabbits
      Rabbits are very efficient breeders and can produce litters at an alarming rate. If you have unfixed male and female rabbits together, nature will most likely take its course and, quicker than you think, you’ll find yourself with several extra mouths to feed.
    </p>
  </li>
  <li>
    <p>
      5. Keeping Your Rabbits Solitary
      A single rabbit can often times be perfectly content on its own. They are generally social animals and tend to thrive on attention. However, rabbit owners usually have a limited amount of time to spend with their bunnies on a daily basis, and bored and lonely rabbits can have a tendency to display self-destructive behavior.
    </p>
  </li>
</ol>
<a href="https://wereallaboutpets.com/important-dos-and-donts-for-rabbits">See More</a>
        
      </div>
    </div>
  </div>
</div>


<div class="grid-container">
  <div class="latest-articles"><h2>Latest Articles</h2></div>
  <div class="grid-section">
    <div class="left-grid">
      <div class="top-picture-grid">
        <img class="grid-pictures"src="/pethub/img/image.png">
      </div>
      <div class="bottom-description-grid">
      <h1> </h1>
      <span class="span-text">
            <p class="learn-more-text">Learn More<i id="right-key" class="material-icons">
              east
            </i></p>
        </span>
      </div>
    </div>
    <div class="middle-grid">
      <div class="top-picture-grid">
        <img class="grid-pictures"src="/pethub/img/image1.png">
        </div>
        <div class="bottom-description-grid">
          <h1></h1>
          <span class="span-text">
          <p class="learn-more-text">Learn More<i id="right-key" class="material-icons">
              east
            </i></p>
          </span>
        </div>
      </div>
    <div class="right-grid">
      <div class="top-picture-grid">
        <img class="grid-pictures"src="/pethub/img/image2.png">
          </div>
          <div class="bottom-description-grid">
            
              <h1></h1>
            
            <span class="span-text">
            <p class="learn-more-text">Learn More<i id="right-key" class="material-icons">
              east
            </i></p>
            </span>
          </div>
        </div>
    </div>
  </div>
  
</div>
<div class="footer">
  <div class="footer-content">
  
    <a href="credits-page.php">
      <p id="group-4-footer">(c) 2024 TSU, Group 4 WEBPROG | All Rights Reserved</p>
    </a>
  </div>
</div>
<script src="navbar.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
   $(document).ready(function() {
  // Bookmark click event
  $(".bookmark-icon").click(function() {
    const sectionId = $(this).attr("name");  // Get the section name
    const sectionTitle = $("#" + sectionId + " h2").text();  // Get the title (h2 text)
    const sectionContent = $("#" + sectionId + " p").text();  // Get the content (p text)

    console.log(sectionTitle, sectionContent); // For debugging, check in browser console

    // Set the category based on the page
    const category = "Fishes";  // Change this dynamically if on a different page
    console.log(sectionTitle, sectionContent)
    // AJAX call to save the bookmark
    $.ajax({
      url: "save_bookmark.php", // PHP file to save the bookmark
      type: "POST",
      data: {
        title: sectionTitle,
        content: sectionContent,
        category: category  // Pass the category (e.g., "Cats")
      },
      success: function(response) {
        alert(response); // Show a confirmation message
      },
      error: function(xhr, status, error) {
        console.error("AJAX Error: " + error); // For debugging in case of error
      }
    });
  });
});
<script src="navbar.js"></script>
<script src="search.js"></script>
  </script>
</body>
</html>

<!-- <span id="grooming-bookmark" name="grooming" class="material-symbols-outlined bookmark-icon" style="font-variation-settings: 'FILL' 0;">bookmark</span> -->