<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the title from the form submission
    $title = htmlspecialchars($_POST['title']); // Sanitize input for security

    // Generate a URL-friendly slug
    $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', trim($title)));

    // Generate the link to the page
    $link = "page.php?title=" . urlencode($slug);

    // Save the title and link in a session (or database)
    session_start();
    $_SESSION['title'] = $title;
    $_SESSION['link'] = $link;

    // Redirect to the display page
    header("Location: saved_bookmarks1.php");
    exit;
}
?>
