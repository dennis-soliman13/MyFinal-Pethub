
function searchWords() {
  const input = document.getElementById("search-bar").value.toLowerCase();
  const content = document.getElementById("content");
  const paragraphs = content.getElementsByTagName("p");
  let found = false;

  for (const paragraph of paragraphs) {
      paragraph.innerHTML = paragraph.textContent;
  }

  if (input) {
      for (const paragraph of paragraphs) {
          if (paragraph.textContent.toLowerCase().includes(input)) {
              found = true;
              const regex = new RegExp(`(${input})`, "gi");
              paragraph.innerHTML = paragraph.textContent.replace(
                  regex,
                  `<span class="highlight">$1</span>`
              );
          }
      }
  }

  document.getElementById("no-results").style.display = found ? "none" : "block";
}
