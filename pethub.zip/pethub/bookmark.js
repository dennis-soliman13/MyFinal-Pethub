
const bookmarkIcon = document.getElementById('bookmark');
const pageTitleInput = document.getElementById('pageTitle');
const bookmarkForm = document.getElementById('bookmarkForm');

// Event listener for the bookmark icon
bookmarkIcon.addEventListener('click', () => {
    // Get the page title
    const pageTitle = document.title;

    // Set the title in the hidden input
    pageTitleInput.value = pageTitle;

    // Submit the form
    bookmarkForm.submit();
});
